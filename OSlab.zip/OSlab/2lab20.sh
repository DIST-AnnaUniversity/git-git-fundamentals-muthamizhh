#!/bin/bash
echo "Enter the directory name"
read directory
if [ -d "$directory" ];
then
echo "A directory exist with that name already"
else
`mkdir $directory`
echo "Directory created"
fi
