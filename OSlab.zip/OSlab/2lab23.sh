#!/bin/bash
echo "Before appending the file "
cat book.txt
echo "Yours faithfully">>book.txt
echo "Always Anbudan Muthamizh">>book.txt
echo"After appending the file"
cat book.txt
