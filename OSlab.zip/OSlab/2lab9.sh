#!/bin/bash
echo "Enter any number"
read number
if [[ ( $number -eq 45 || $number -eq 55 ) ]];
then 
echo "You won"
else
echo "Your guess was wrong"
fi
