echo "Enter your name"
read name
echo "Your name is "$name

