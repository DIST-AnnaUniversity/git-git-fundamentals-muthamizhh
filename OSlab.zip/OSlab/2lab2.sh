#!/bin/bash
#To add two numbers
((sum=1+2))
echo $sum
