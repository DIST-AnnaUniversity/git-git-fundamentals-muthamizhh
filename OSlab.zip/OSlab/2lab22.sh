#!/bin/bash
echo "Enter the file name"
read fn
rm -i $fn
