#!/bin/bash
string1="Linux"
string2="Hunt"
echo $string1$string2
string3=$string1+$string2
string3+="Is good for os programming believe"
echo $string3

