#!/bin/bash
echo "Enter the username"
read username
echo "Enter the password"
read password
if [[ ( $username == "Username" && $password == "password" ) ]]; then 
echo "permission granted"
else
echo "permission denied invalid credentials"
fi
