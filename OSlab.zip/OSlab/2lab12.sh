#!/bin/bash
echo "The total number of arguments is : $#"
echo "The first argument is $1"
echo "The second argument is $2"
