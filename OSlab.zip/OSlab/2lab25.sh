#!/bin/bash
echo "Enter your mail id"
read email
Subject="Greeting Sir"
Message="Welcome onboard Commanding Officer"
`mail -s $Subject $email <<< $Message`
