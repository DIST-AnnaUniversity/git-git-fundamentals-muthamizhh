#!/bin/bash
echo "Enter your lucky number"
read number
if [ $number -eq 19 ];
then 
echo "You won 1st price"
elif [ $number -eq 25 ];
then 
echo "You won the second prize"
elif [ $number -eq 30 ];
then
echo "You wont the third price"
else
echo "YOur guess was wrong"
fi
