#!/bin/bash
echo "Program to create a function"
function h1(){
echo "Hello world"
echo "Function created"
}
h1
