echo "Enter Your name"
read name
function greeting(){
echo $name
}
val=$(greeting)
echo "Your name is $name"

