#!/bin/bash
function greeting(){
str="Welcome to OS lab"
echo $str
}
echo "Enter your name"
read name
val=$(greeting)
echo "$val $name"

