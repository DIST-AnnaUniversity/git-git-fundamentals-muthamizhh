#!/bin/bash
: '
This program is written to 
demonstrate mulitline comment statements
'
((area = 5*5 ))
echo $area
