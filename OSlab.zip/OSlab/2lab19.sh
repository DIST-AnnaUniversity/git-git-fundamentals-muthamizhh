#!/bin/bash
echo "Enter the director name"
read dire
`mkdir $dire`
