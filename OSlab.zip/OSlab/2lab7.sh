#!/bin/bash
echo "Enter a number"
read number
if [ $number -lt 10 ];
then 
echo "It is a single digit number"
else
echo "It is a number greater than one digit"
fi
