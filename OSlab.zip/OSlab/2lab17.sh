#!/bin/bash
echo "program to create a function with parameters"
function add(){
area=$(($1 * $2))
echo "The are of the rectangle is $area"
}
add 10 20
