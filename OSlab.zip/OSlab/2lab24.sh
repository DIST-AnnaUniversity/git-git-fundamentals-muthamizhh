#!/bin/bash
filename=$1
if [ -f $filename ];
then 
echo "File exists"
else
echo "The file does not exist"
fi
