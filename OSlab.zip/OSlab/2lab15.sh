#!/bin/bash
echo "Enter the first number"
read n
echo "Enter the second number"
read m
(( sum=m+n ))
echo "The sum of the two numbers is $sum"

