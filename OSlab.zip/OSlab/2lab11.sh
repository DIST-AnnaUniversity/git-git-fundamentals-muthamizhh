#!/bin/bash
echo "Enter a number"
read n
case $n in 
101)
echo "You won the first prize";;
105)
echo "You won the second prize";;
110)
echo "You won the third prize";;
*)
echo "Better luck next time";;
esac
