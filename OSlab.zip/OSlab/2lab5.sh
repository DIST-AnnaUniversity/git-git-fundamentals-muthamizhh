#!/bin/bash
for (( counter=0; counter<10; counter++ ))
do
echo \ "$counter"
done
printf "\n"

