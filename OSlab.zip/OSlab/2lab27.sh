#!/bin/bash
Year=`date +%Y`
Month=`date +%m`
Day=`date +%d`
Hour=`date +%H`
Minute=`date +%M`
Second=`date +%S`
echo `date`
echo "Current Date - $Day-$Month-$Year"
echo "Current Time - $Hour:$Minute:$Second"
