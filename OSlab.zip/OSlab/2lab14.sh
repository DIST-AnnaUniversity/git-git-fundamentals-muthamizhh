#!/bin/bash
str="Learn Linux from Linux Hint"
substr=${str:6:5}
echo $substr

